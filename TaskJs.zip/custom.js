fetchProducts();
function fetchProducts(){
fetch('hotel.json')
	.then(function (response) {
		return response.json();
	}).then(function (data) {
		setHotelDetail(data);
	}).catch(function (error) {
		console.log(error);
	});
}
var allItems;
var ages=[];
var seasons=[];
var resorts=[];
var load=15;
var totalRows=0;
function setHotelDetail(data){
	allItems=data;
	$.each(data,function(i,item)
	{
	if(ages.indexOf(item.age) == -1)
	{
		ages.push(item.age);
		if(item.age){
		 $("#age").append("<option value='"+item.age+"'>"+item.age+"</option>");
		}
	}
	if(seasons.indexOf(item.season) == -1)
	{
		seasons.push(item.season);
		if(item.season){
		 $("#season").append("<option value='"+item.season+"'>"+item.season+"</option>");
		}
	}
	if(resorts.indexOf(item.resorttype) == -1)
	{
		resorts.push(item.resorttype);
		if(item.age){
		 $("#resortType").append("<option value='"+item.resorttype+"'>"+item.resorttype+"</option>");
		}
	}
	});
	setData();
	
}

function setData()
{
	var age=$("#age").val();
	if(age !='')
	{
		$('.ageFilter').remove();
		$('#filters').append('<button type="button" class="btn btn-primary ageFilter" onclick=removeFilter("age","ageFilter")>'+age+' &times; </button> ');
	}
	
	var season=$("#season").val();
	var resortType=$("#resortType").val();
	if(season !='')
	{
		$('.seasonFilter').remove();
		$('#filters').append('<button type="button" class="btn btn-primary seasonFilter" onclick=removeFilter("season","seasonFilter")>'+season+' &times; </button> ');
	}
	if(resortType !='')
	{
		$('.resortTypeFilter').remove();
		$('#filters').append('<button type="button" class="btn btn-primary resortTypeFilter" onclick=removeFilter("resortType","resortTypeFilter")>'+resortType+' &times; </button> ');
	}
	var sortBy=$("#sortBy").val();
	$("#hotels").empty();
	  if(sortBy=='htl')
	{
		allItems=allItems.sort((a, b) => 
		{
			if( !isFinite(parseFloat(a.price)) && !isFinite(parseFloat(b.price)) ) {
			return 0;
			}
			if( !isFinite(parseFloat(a.price)) ) {
				return 1;
			}
			if( !isFinite(parseFloat(b.price)) ) {
				return -1;
			}
			return parseFloat(b.price)-parseFloat(a.price);	
		});
	}
	else if(sortBy=='atz')
	{
		allItems=allItems.sort(function(a,b){
			if(a.name < b.name) { return -1; }
			if(a.name > b.name) { return 1; }
			return 0;
			})
	}
	else if(sortBy=='zta')
	{
		allItems=allItems.sort(function(a,b){
			if(a.name < b.name) { return 1; }
			if(a.name > b.name) { return -1; }
			return 0;
			})
	}
	else
	{
		allItems=allItems.sort((a, b) => {
			if( !isFinite(parseFloat(a.price)) && !isFinite(parseFloat(b.price)) ) {
				return 0;
			}
			if( !isFinite(parseFloat(a.price)) ) {
				return 1;
			}
			if( !isFinite(parseFloat(b.price)) ) {
				return -1;
			}
			return parseFloat(a.price)-parseFloat(b.price);
		});
		
	}
			
	
	$.each(allItems,function(i,item)
	{
	if(item.id) {
	var imagee=item.image;
	if(!imagee)
	{ 
		imagee='./images/Placeholder-image.jpg';
	}
	    var productDiv="<div class='row' ><div class='col-sm-2'><img src='"+imagee+"' alt='Hotel Image' title='Hotel Image' class='hotel_img'></div><div class='col-sm-8'><div class='hotel-details'><h3>"+item.name+"</h3><p>"+item.address.streetAddress+','+item.address.addressLocality+', '+item.address.addressRegion+' - '+item.address.postalCode+" <br> "+item.contactPoint.telephone+"</p><p><b>Rated "+item.star+"</b> based on <span>"+item.reviewscount+"</span> reviews<br><span><b>"+item.age+" - "+item.season+"</b></span>	</p></div></div><div class='col-sm-2'>From <b>"+item.price+" USD/Night </b> <h5></h5></div></div><hr/>";
		if(i< load){
		 if(season!='' && age!='' && resortType!='')
		{
			if(season ==item.season && age ==item.age && resortType.indexOf(item.resorttype) > -1 ){
			$("#hotels").append(productDiv);
			}
		}
		else if(season!='' && age!='' )
		{
			if(season ==item.season && age ==item.age ){
			$("#hotels").append(productDiv);
			}
		}
		else if(resortType!='' && age!='' )
		{
			if(resortType.indexOf(item.resorttype) > -1 && age ==item.age ){
			$("#hotels").append(productDiv);
			}
		}
		else if(resortType!='' && season!='' )
		{
			if(resortType.indexOf(item.resorttype) > -1 && season ==item.season ){
			$("#hotels").append(productDiv);
			}
		}
		else if(age!='')
		{
			if(age ==item.age){
			$("#hotels").append(productDiv);
			}
		}
		else if(season!='')
		{
			if(season ==item.season){
			$("#hotels").append(productDiv);
			}
		}
		else if(resortType!='')
		{
			if(resortType.indexOf(item.resorttype) > -1 ){
			$("#hotels").append(productDiv);
			}
		}
		else
		{
		   $("#hotels").append(productDiv);
		}
		}
	}
	});
	
    totalRows=$('#hotels .row').length ;
	 $('#totCount').html(totalRows);
	
}

$(window).scroll(function() {
    if(Math.ceil($(window).scrollTop()) >= Math.ceil(($(document).height() - $(window).height()-5))) {
	load=parseInt(load)+15;
	setTimeout(setData(),1000);
        
    }
	
	
}); 

function printData()
{
	
var w = window.open();
  w.document.write('<html><head><title></title>');
  w.document.write('<link rel="stylesheet" type="text/css"  href="./bootstrap/css/bootstrap.min.css"  >');
  w.document.write('<link rel="stylesheet" type="text/css"  href="custom.css"  >');
  w.document.write('</head><body >');
  w.document.write(document.getElementById('hotels').innerHTML);
  w.document.write('<script type="text/javascript" src="./bootstrap/js/bootstrap.bundle.min.js"></script>');
  w.document.write('</body></html>');

  w.document.close();
  w.focus();
  w.print();
  w.close();
  return true;
}

function removeFilter(filter,cls)
{
	$('.'+cls).remove();
	$('#'+filter).val('');
	$('#'+filter+' option:first').attr('selected','selected');
	setTimeout(function(){
		$('#'+filter).trigger('change');
		},0)
	
	
}